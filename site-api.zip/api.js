function cadastrarUsuario() {
  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  const data = {
    "name": name,
    "email": email,
    "username": username,
    "password": password
  };

  const url = 'https://todolist-api.edsonmelo.com.br/api/user/new/';

  const headers = {
    'Content-Type': 'application/json'
  };

  fetch(url, {
    method: 'POST',
    body: JSON.stringify(data),
    headers: headers
  })
    .then(response => {
      if (!response) {
        throw new Error('Erro ao criar usuário');
      }
      return response.json();
    })
    .then(data => {
      console.log('Usuário criado:', data);
    })
    .catch(error => {
      console.error('Erro ao criar usuário:', error);
    });
};

function fazerLoginEAlterarDados() {
  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const username = document.getElementById("username").value;
  const password = document.getElementById("current-password").value;

  const url = `https://todolist-api.edsonmelo.com.br/api/user/update/`;

  const data = {
    name: name,
    email: email,
    username: username,
    password: password
  };

  fetch(url, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify(data)
  })
    .then(response => response.json())
    .then(data => {
      console.log(data);
      alert("Dados alterados com sucesso!");
    })
    .catch((error) => {
      console.error('Erro:', error);
      alert("Ocorreu um erro ao tentar alterar os dados. Por favor, tente novamente.");
    });
}

function login() {
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  const data = {
    "username": username,
    "password": password
  };

  const url = 'https://todolist-api.edsonmelo.com.br/api//user/login/';

  const headers = {
    'Content-Type': 'application/json'
  };

  fetch(url, {
    method: 'POST',
    body: JSON.stringify(data),
    headers: headers
  })
    .then(response => {
      if (!response) {
        throw new Error('Erro ao fazer login');
      }
      return response.json();
    })
    .then(data => {
      console.log('Usuário autenticado:', data);
      const token = data.token;
      // redireciona para a página de perfil do usuário
      // window.location.href = 'perfil.html';

      console.log(token)
    })
    .catch(error => {
      console.error('Erro ao fazer login:', error);
    });
};

